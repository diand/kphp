<?php

	$h=DB_HOST;
	$u=DB_USERNAME;
	$p=DB_PASSWORD;		
	$d=DB_NAME;
	$GLOBALS['d']=$d; 
	$con=mysql_connect($h,$u,$p);
	$db =mysql_select_db($d);
if(!$con or !$db)
{
echo "<h2>Sorry, Database is Down :(</h2><br>#DT<br>Please Call 0813 2278 2862 for Urgent Matter.";
exit();
}
?>