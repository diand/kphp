<?php
	//Display
	function display_as($list,$from,$to)
	{
		for($i=0;$i<=count($from);$i++)
		{
			
			echo $i."-".$from[$i]."-";
			if($list==$from[$i]){
				return $to[$i];
			}else{
				return $list;
			}
		}		
	}
	
	//Database Query Tools
	function getCount($tbl,$cond=null)
	{
		if(!empty($cond))
		{
			$wh = " and ".$cond;
		}else{
			$wh = "";
		}
		$jlh = mysql_num_rows(mysql_query("select * from ".$tbl." where 1=1".$wh));
		return $jlh;
	}
	
	//Form ALert
	function alert_success()
	{
		$alert = "
			<div class=\"alert alert-success alert-dismissable\">
			    <i class=\"fa fa-check\"></i>
			    <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>
			    <b>Selamat!</b> Data Berhasil diproses
			</div>
			 			
			<script>
				var delay = 1000; //Your delay in milliseconds
				setTimeout(function(){ window.location = 'index.php?m=".$_GET['m']."'; }, delay);
			</script>
			 
			";
		return $alert;
	}
	
	function alert_failed()
	{
		$alert = "		
			<div class=\"alert alert-danger alert-dismissable\">
			    <i class=\"fa fa-ban\"></i>
			    <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>
			    <b>Maaf!</b> Data gagal diproses!
			</div>";
		return $alert;
	}
	
	function alert($msg)
	{
		$alert = "		
			<div class=\"alert alert-info alert-dismissable\">
			    <i class=\"fa fa-info\"></i>
			    <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-hidden=\"true\">&times;</button>
			    ".$msg."
			</div>";
		return $alert;
	}
	
	// Form Database Tool	
	//form input
	function form_input($col,$type='text',$val=null,$tag=null)
	{
		$inp = "<input 
				type='".$type."' 
				".$tag." 
				name='".$col."' 
				placeholder='".str_replace("_"," ",strtoupper($col))."' 
				id='".$col."' 
				value='".$val."'
				/>";	    					
		return $inp;
	}
	
	function form_now($col,$type='date',$tag=null)
	{
		$inp = "<input 
				type='".$type."' 
				".$tag." 
				name='".$col."' 
				placeholder='".str_replace("_"," ",strtoupper($col))."' 
				id='".$col."' 
				value='".date('Y-m-d h:i:s')."'
				/>";	    					
		return $inp;
	}
	
	//form textarea
	function form_textarea($col,$val=null,$tag=null)
	{
		$inp = "<textarea class='span12 cleditor'
				rows=\"3\" 
				name='".$col."' 
				placeholder='".str_replace("_"," ",strtoupper($col))."' 
				id='".$col."' ".$tag.">".$val."</textarea>";	    					
		return $inp;
	}
	
	//form dropdown
	function form_dropdown_enum($tbl,$col,$selected=null,$tag=null)
	{
		$inp = "<select class=\"cho\" ".$tag." name=\"".$col."\">";
				$inp .= "<option value=\"\">Pilih</option>";
   				$result = mysql_query("SELECT COLUMN_TYPE FROM INFORMATION_SCHEMA.COLUMNS
				WHERE TABLE_SCHEMA = '".$GLOBALS['d']."' and TABLE_NAME = '".$tbl."' AND COLUMN_NAME = '".$col."'") or die (mysql_error());
				$row = mysql_fetch_array($result);
				$enumList = explode(",", str_replace("'", "", substr($row['COLUMN_TYPE'], 5, (strlen($row['COLUMN_TYPE'])-6))));
				foreach($enumList as $value){
					if(!empty($selected) and $selected==$value)
					{
						$s="selected";
					}else{
						$s="";
					}
					$inp .= "<option $s value=\"$value\">$value</option>";
				}
				$inp .= "</select>";
		return $inp;
	}
	
	
	//form dropdown
	function form_dropdown_table($tbl,$col,$id_col,$sql_cond=null,$selected=null,$tag=null)
	{
		if(is_array($col)==true){			
			$name_col = $col[0];
		}else{
			$name_col = $col;
		}
		if(!empty($sql_cond))
		{
			$wh = " and ".$sql_cond;
		}else{
			$wh = "";
		}
		$inp = "<select class=\"cho\" ".$tag." name=\"".$id_col."\">";
		$inp .= "<option value=\"\">Pilih</option>";
		$result = mysql_query("SELECT * FROM ".$tbl." WHERE 1=1 ".$wh);
			//echo "SELECT * FROM ".$tbl." WHERE 1=1 ".$wh."<br>";
			//echo $selected;
			while($row = mysql_fetch_array($result))
			{
				$display_col = "";						
				if(is_array($col)==true){			
					foreach($col as $show_col)
					{
						$display_col .= $row[$show_col]." ";
					}
				}else{
					$display_col = $row[$col];
				}
				if(!empty($selected) and $selected==$row[$name_col])
				{
					$s="selected";
				}else{
					$s="";
				}
				$inp .= "<option $s value=\"".$row[$name_col]."\">".$display_col."</option>";
			}
		$inp .= "</select>";
		
		return $inp;
	}
	
	function upload($col,$rename,$path)
	{             
            $tmp_name = $_FILES[$col]["tmp_name"];
            $name = $rename.$_FILES[$col]["name"];
            move_uploaded_file($tmp_name,$path."/".$name);
	}
	
?>