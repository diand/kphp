<?php
	
	 
	function quiz($option)
	{
		foreach ($option['slev'] as $key => $value) {
			switch ($key) {
				case 'read':
					echo quizRead($option);
					break;
				default:
					# code...
					break;
			}		
		}
		 
	}
	 

	function quizRead($read) 
	{
		error_reporting(0);
		$out="";
		//initiate the Tables
		if(empty($_GET['op']))
		{
			$col  = "";
			$tbl  = "";
			$pk   = "";
			$slev = "";
			foreach ($read as $key => $value) {
				switch ($key) {
					case 'col':
						$col = $value;
						break;
					case 'tbl': 
						$tbl = $value;
						break;
					case 'pk':
						$pk = $value;
						break;
					case 'slev':
						$slev = $value;
						break;
					default:
						# code...
						break;
				}
			}

			$sql = "select $col from $tbl order by 1 asc";
			$query = mysql_query($sql);
    

			if(isset($_POST['simpan'])){
				
				//manual
				while($dtQ = mysql_fetch_array($query))
				{
					$jwb = "soal_".$dtQ['id_soal_choice'];									
					$ins = mysql_query("insert into jawaban_soal_choice values('','".$_SESSION['sess_id_login']."','".$dtQ['id_soal_choice']."','".$_POST[$jwb]."',NOW(),NOW())");
				
				}
				
		        if($ins){
		        	$out .=  alert_success();
		        }else{
		        	$out .=  alert_failed();
		        }
			}


			$out .= "
			<div class=\"row-fluid\">
				<div class=\"span12\">
					<div class=\"box\">
				<div class=\"box-head tabs\">
					<h3>Data ".ucwords(str_replace("_", " ", $_GET['m']))."</h3>							
					<ul class='nav nav-tabs'>
						<li>";
						

			$out .="	</li>
					</ul>

				</div>
				<div class=\"box-content box-nomargin\">
					<div class=\"tab-content\">
				
					<form action='' class='form-horizontal form validate' method='post' enctype='multipart/form-data'>
					<fieldset>
				 
						<div class=\"tab-pane active\" id=\"basic\">
							<table class='table table-striped table-bordered'> 
						   	<thead>
						    	<tr>
						    	<th>NO</th>
				    ";	
				    	//cols
				    	$i=0;
				    	while ($i < mysql_num_fields($query)) {
				    		$meta = mysql_fetch_field($query,$i);
					    	if (!$meta) {
				    		    $out .=  "No information available<br />\n";
					    	}else{	    	
					    		if($meta->name!=$pk){ 
					    			//check if the relation is exist
					    			if(array_key_exists($meta->name, $read['rel']['1_n'])){
					    				$colName = str_replace("_"," ",strtoupper($read['rel']['1_n'][$meta->name]['display']));
					    			}else{
					    				$colName = str_replace("_"," ",strtoupper($meta->name));
					    			}
					    			$out .= "<th>".$colName."</th>";        	
				    	    	}
				        	}
					    	$i++;
				        }

						

				$out .= "       
				        </tr>
				  	</thead>
				    <tbody>";
				    	
				    	//rows
				    	$no=1;	
				    	while($rows = mysql_fetch_array($query)){
				    		$out .=  "<tr>";
				    		$out .=  "<td>$no</td>";
				    		$i=0;
				    		while ($i < mysql_num_fields($query)) {
				    			$meta = mysql_fetch_field($query,$i);
						    	if (!$meta) {
				    			    $out .=  "No information available<br />\n";
					    		}else{	   
					    			if($meta->name!=$pk){

						    			//check if the relation is exist
						    			if(array_key_exists($meta->name, $read['rel']['1_n'])){
						    				$dtNew = mysql_fetch_array(mysql_query("select 
						    							".$read['rel']['1_n'][$meta->name]['display']." 
						    							 from ".$read['rel']['1_n'][$meta->name]['tbl']." 
						    							 where 
						    							 	".$read['rel']['1_n'][$meta->name]['id_col']." = '".$rows[$meta->name]."'"));

						    				$val = $dtNew[$read['rel']['1_n'][$meta->name]['display']];
						    			}else{
						    				//check is a file or image
						    				$fileName = explode(".", strtolower($rows[$meta->name]));
						    				$extFile = $fileName[count($fileName)-1];
					    					if($extFile == 'jpg' or $extFile == 'png' or $extFile == 'gif' or $extFile == 'jpeg')
					    					{
					    						$val = "<center><a href=\"files/".$rows[$meta->name]."\" class='preview fancy'><img src=\"files/".$rows[$meta->name]."\" width='64px' alt='' title=\"".$rows[$meta->name]."\"></a></center>";
					    					}elseif($extFile == 'docx' or $extFile == 'doc' or $extFile == 'pdf'   or $extFile == 'ppt'  or $extFile == 'pptx'){
					    						$val = "<center><a href=\"files/".$rows[$meta->name]."\"><img src=\"img/icons/fugue/arrow-270.png\" alt='' title=\"".$rows[$meta->name]."\"></a></center>";
					    					}else{
					    						$val = $rows[$meta->name];
					    					}
						    			}
						    			
										if(strtolower($meta->name) == 'a' or 
										   strtolower($meta->name) == 'b' or 
										   strtolower($meta->name) == 'c' or 
										   strtolower($meta->name) == 'd' or 
										   strtolower($meta->name) == 'e'){
											$optRadio="<input type='radio' name='soal_".$rows[$pk]."' value='".$meta->name."'>";
										}else{
											$optRadio="";
											}
											
				    		    		$out .=  "<td><p>".$optRadio."<br> ".$val."</p></td>";           	
				    		    	} 		
					        	}	        	
						    	$i++;
				        	}
				        //set Body Level who can Update Delete and Detail


				    	$out .=  "</tr>"; 
				    	$no++;   		
				    	}
				    	   
			$out .= "          		
				    </tbody>                                        
				</table>
					</div>	 
				<div class=\"form-actions\">
					<button type=\"button\" onclick = \"javascript:location.replace('index.php?m=".$_GET['m']."')\" class=\"btn btn-danger\"  name='batal'>Batal</button>
					<button type=\"submit\" class=\"btn btn-primary\"  name='simpan'>Submit</button>
					
				</div>
				</fieldset>
					</form>
					</div>
				</div>
			</div>                
 				";
		}

		if(is_array($read['slev']['read'])){
			if(is_numeric(array_search($_SESSION['sess_level'], $read['slev']['read']))){
				return $out;	
			}
		}else{
			return $out;	
		}
			
	}




?>