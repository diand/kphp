<?php

	function login($tbl,$un,$pw,$pk,$sess_login,$sess_level)
	{

		
		$_SESSION['sess'] = array(
							'tbl' => $tbl, 
							'un'=>$un,
							'pw'=>$pw,
							'pk'=>$pk,
							'slogin'=>$sess_login,
							'slevel'=>$sess_level
							);
		
		$disp = "
			<div class='login_body'>
		        <div class=\"wrap\">
		            <h2>Login</h2>
		            <form action=\"index.php?m=login_db\" autocomplete=\"off\" method=\"post\">
		                <div class=\"login\">
		                    <div class=\"email\">
		                        <label for=\"user\">Username</label>
		                        <div class=\"email-input\">
		                            <div class=\"input-prepend\"><span class=\"add-on\"><i class=\"icon-envelope\"></i></span>
		                            <input type=\"text\" name=\"uname\" required  placeholder=\"Username\"/>
		                            </div>
		                        </div>                        
		                    </div>
		                    <div class=\"pw\">
		                        <label for=\"pw\">Password</label>
		                        <div class=\"pw-input\">
		                            <div class=\"input-prepend\"><span class=\"add-on\"><i class=\"icon-lock\"></i></span>
		                            <input type=\"password\" required id=\"pw\" name=\"pwd\" placeholder=\"Password\"/>
		                            </div>
		                        </div>
		                    </div>          
		                </div>
		                <div class=\"submit\">
		                    <button type=\"submit\" name=\"login\" class=\"btn btn-red5\">Login</button>                      
		                </div> 
		            </form>
		        </div>
		    </div>         
		";

		echo $disp;
	}

	if(!empty($_GET['m']) and $_GET['m']=='login_db' and isset($_POST['login'])){
		
			$q = mysql_query("select * from ".$_SESSION['sess']['tbl']." 
			where ".$_SESSION['sess']['un']." = '".$_POST['uname']."' and ".$_SESSION['sess']['pw']." = '".$_POST['pwd']."'");
			$dt = mysql_fetch_array($q);		
			if( mysql_num_rows($q) > 0 )
			{
				//jika level tidak ditemukan di database maka akan di set sesuai dengan yg ada pada variable
				if(empty($dt[$_SESSION['sess']['slevel']]))
				{
					$level = $_SESSION['sess']['slevel'];
				}else{
					$level = $dt[$_SESSION['sess']['slevel']];
				}

				$_SESSION['sess_login']=$dt[$_SESSION['sess']['slogin']];
				$_SESSION['sess_id_login']=$dt[$_SESSION['sess']['pk']];
				$_SESSION['sess_level']=$level;
				?>
					<script>
						window.location='index.php';
					</script>
				<?php
			}else{
				?>
				<script>
				alert("Maaf Username dan Password Tidak di temukan");
				window.location='index.php?m=<?php echo $_GET['m']; ?>';
				//history.back();
				</script>
				<?php
			}
		
	}

	if(!empty($_GET['m']) and $_GET['m']=='logout'){
		session_destroy();
			?>
				<script>
					window.location='index.php?m=home';
				</script>
			<?php
	}
	
?>