<?php
//Database Config
define("DB_HOST", "localhost");
define("DB_USERNAME", "root");
define("DB_PASSWORD", "");
define("DB_NAME", "elearning_matematika");

//Directory Config
define("APPLICATION", "application/");
define("TEMPLATE", "template/");
define("MENU", "template/menu/");

//Template Config

//Content Config
define("TITLE", "KPHPv2");

?>